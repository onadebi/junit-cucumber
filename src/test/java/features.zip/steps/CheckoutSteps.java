package steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.junit.Assert.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;

import io.cucumber.java.en.*;

public class CheckoutSteps {

    StringBuilder sb = new StringBuilder();
    static Integer total = 0;
    public CheckoutSteps(){
        sb.append("Items: ");
    }

static Map<String, Integer[]> checkoutItems = new HashMap<String, Integer[]>();

@Given("^the checkout system has the following pricing rules$")
public void the_checkout_system_has_the_following_pricing_rules() {
    // Write code here that turns the phrase above into concrete actions
    System.out.println("the_checkout_system_has_the_following_pricing_rules");
}

@When("the cashier scans the following items in any order: {string} with unit price of {int}. Posible specialPrice is {string}")
public void the_cashier_scans_the_following_items_in_any_order_with_unit_price_of_possible_special_price(String shoppedItem, Integer unitPrice, String specialPrice) {
    // Write code here that turns the phrase above into concrete actions
	if(checkoutItems.containsKey(shoppedItem)) {
        String[] discount = new String[2];
		if(specialPrice != null && !specialPrice.isBlank()) {
			discount = specialPrice.split("for");
		}
		checkoutItems.computeIfPresent(shoppedItem,(k,v) -> v[0] += 1, unitPrice);
	}else {
		checkoutItems.put(shoppedItem, unitPrice);
	}
    System.out.println(String.format("the_cashier_scans_the_following_items: %s, which has price of %s.",shoppedItem, unitPrice));
}

@Then("the total price should be {int} cents")
public void the_total_price_should_be_cents(Integer int1) {
    // Write code here that turns the phrase above into concrete actions
   
    for (Map.Entry<String, Integer> entry : checkoutItems.entrySet()) {
        sb.append(String.format("%s,", entry.getKey()));
        total += entry.getValue();
    }
    System.out.println(String.format("The total amount value is %s", total));
}


}
